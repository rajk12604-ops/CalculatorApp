
package com.example.calculatorapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.math.BigDecimal;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener {

    private TextView tvDisplay, tvExpression;
    private String input = "0";
    private String operator = "";
    private double firstValue = 0;
    private boolean newInput = true;
    private boolean error = false;

    private final int[] ids = {
            R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3,
            R.id.btn4, R.id.btn5, R.id.btn6, R.id.btn7,
            R.id.btn8, R.id.btn9, R.id.btnDot,
            R.id.btnClear, R.id.btnSign, R.id.btnPercent,
            R.id.btnBackspace, R.id.btnPlus, R.id.btnMinus,
            R.id.btnMultiply, R.id.btnDivide, R.id.btnEquals
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvDisplay = findViewById(R.id.tvDisplay);
        tvExpression = findViewById(R.id.tvExpression);

        for (int id : ids) {
            View button = findViewById(id);
            if (button != null) {
                button.setOnClickListener(this);
            }
        }
    }

    @Override
    public void onClick(View view) {
        String key = ((Button) view).getText().toString();

        if (key.matches("[0-9]")) {
            enterDigit(key);
            return;
        }

        switch (key) {
            case ".":
                enterDecimal();
                break;
            case "C":
            case "AC":
                clear();
                break;
            case "⌫":
                backspace();
                break;
            case "±":
                if (!error && !input.equals("0")) {
                    input = input.startsWith("-")
                            ? input.substring(1) : "-" + input;
                    show();
                }
                break;
            case "%":
                if (!error) {
                    input = format(number() / 100.0);
                    newInput = true;
                    show();
                }
                break;
            case "+":
            case "−":
            case "×":
            case "÷":
                setOperator(key);
                break;
            case "=":
                calculate();
                break;
        }
    }

    private double number() {
        return Double.parseDouble(input);
    }

    private void enterDigit(String digit) {
        if (error) clear();

        if (newInput || input.equals("0")) {
            input = digit;
            newInput = false;
        } else if (input.replace("-", "").length() < 15) {
            input += digit;
        }
        show();
    }

    private void enterDecimal() {
        if (error) clear();

        if (newInput) {
            input = "0.";
            newInput = false;
        } else if (!input.contains(".")) {
            input += ".";
        }
        show();
    }

    private void setOperator(String value) {
        if (error) return;

        if (!operator.isEmpty() && !newInput) {
            if (!compute()) return;
        } else if (operator.isEmpty()) {
            firstValue = number();
        }

        operator = value;
        tvExpression.setText(format(firstValue) + " " + operator);
        newInput = true;
    }

    private boolean compute() {
        double second = number();
        double result;

        switch (operator) {
            case "+":
                result = firstValue + second;
                break;
            case "−":
                result = firstValue - second;
                break;
            case "×":
                result = firstValue * second;
                break;
            case "÷":
                if (second == 0) {
                    showError();
                    return false;
                }
                result = firstValue / second;
                break;
            default:
                return false;
        }

        if (Double.isNaN(result) || Double.isInfinite(result)) {
            showError();
            return false;
        }

        firstValue = result;
        input = format(result);
        show();
        return true;
    }

    private void calculate() {
        if (error || operator.isEmpty() || newInput) return;

        String expression = format(firstValue) + " "
                + operator + " " + input + " =";

        if (compute()) {
            tvExpression.setText(expression);
            operator = "";
            newInput = true;
        }
    }

    private void backspace() {
        if (error) {
            clear();
            return;
        }

        if (newInput) {
            input = "0";
            newInput = false;
        } else if (input.length() > 1) {
            input = input.substring(0, input.length() - 1);
            if (input.equals("-")) input = "0";
        } else {
            input = "0";
        }
        show();
    }

    private void clear() {
        input = "0";
        operator = "";
        firstValue = 0;
        newInput = true;
        error = false;
        tvExpression.setText("");
        show();
    }

    private void showError() {
        input = "Error";
        operator = "";
        firstValue = 0;
        newInput = true;
        error = true;
        tvDisplay.setText("Error");
    }

    private String format(double value) {
        return BigDecimal.valueOf(value)
                .stripTrailingZeros().toPlainString();
    }

    private void show() {
        tvDisplay.setText(input);
    }
}
